"""
app.py  –  Streamlit review & reconciliation UI
Run with:  streamlit run app.py
"""

from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from bank_parser import parse_bank_file, parse_debit_file, extract_comment_text
from tenant_loader import load_tenants
from matcher import match_transactions, FUZZY_THRESHOLD
from excel_updater import apply_matches, apply_expense_matches, LedgerUpdater, ExpenseUpdater

st.set_page_config(
    page_title="האגמית 7 – גביה",
    page_icon="🏢",
    layout="wide",
)

st.markdown("""
<style>
  body, .stApp, .stDataFrame { direction: rtl; }
  thead tr th { text-align: right !important; }
  /* Fix slider tooltip alignment in RTL */
  div[data-baseweb="slider"] { direction: ltr; }
</style>
""", unsafe_allow_html=True)

st.title("🏢 האגמית 7 – התאמת תשלומים")

for key in ("matched","unmatched","tenants","ledger_path","payment_month","written","skipped",
            "debits_matched","debits_unmatched","expense_written","expense_skipped"):
    if key not in st.session_state:
        st.session_state[key] = None

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "⚙️ הרצה", "✅ התאמות אוטומטיות", "🔍 בדיקה ידנית", "💸 הוצאות", "📋 יומן כתיבה"
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 – Run
# ══════════════════════════════════════════════════════════════════════════════
with tab1:
    st.subheader("קבצי קלט")
    col1, col2 = st.columns(2) # Changed to 2 columns

    with col1:
        bank_file = st.file_uploader("קובץ בנק (.xls/.xlsx/.csv)", type=["xls","xlsx","csv"])
    with col2:
        ledger_file = st.file_uploader("גיליון ניהול (.xlsx)", type=["xlsx"])

    st.divider()

    col_a, col_b, col_c = st.columns(3)
    with col_a:
        # Generates a list: ['01/2026', '02/2026', ..., '12/2026']
        months_2026 = [f"{m:02d}/2026" for m in range(1, 13)]
        
        month_input = st.selectbox(
            "חודש לעדכון (MM/YYYY)",
            options=months_2026,
            help="בחר חודש מתוך שנת 2026"
        )
    with col_b:
        threshold = st.slider(
            "סף התאמה פאזי (%)", 50, 100, FUZZY_THRESHOLD,
            help="התאמות מתחת לסף יועברו לבדיקה ידנית"
        )
    with col_c:
        overwrite = st.checkbox(
            "דרוס ערכים קיימים",
            value=False,
            help="החלף סכומים קיימים בתא. נוסחאות לעולם לא יידרסו."
        )

    st.caption("💡 הגדרות גיליון קבועות: שורת כותרת 1 · עמודת דירה B · גיליון 'גביה 2026'")

    st.divider()
    run_btn = st.button("▶ הרץ התאמה", type="primary", use_container_width=True)

    if run_btn:
        roster_path = Path("tenants.csv") # Looks in your main folder
        
        errors = []
        if not bank_file:   errors.append("נא להעלות קובץ בנק")
        if not ledger_file: errors.append("נא להעלות גיליון ניהול")
        if not roster_path.exists(): errors.append("לא נמצא קובץ tenants.csv בתיקייה הראשית")

        if errors:
            for e in errors: st.error(e)
        else:
            tmp = Path("tmp/vaad") 
            tmp.mkdir(parents=True, exist_ok=True)
            bank_path   = tmp / bank_file.name
            roster_path = tmp / "tenants.csv"
            ledger_path = tmp / "master_ledger.xlsx"

            bank_path.write_bytes(bank_file.read())
            ledger_path.write_bytes(ledger_file.read())

            with st.spinner("מנתח קובץ בנק…"):
                try:
                    transactions = parse_bank_file(str(bank_path))
                except Exception as e:
                    st.error(f"שגיאה בניתוח קובץ בנק: {e}"); st.stop()

            with st.spinner("מנתח הוצאות מהבנק…"):
                try:
                    # Resolve categories.csv next to app.py — never rely on cwd
                    cats_path = Path(__file__).parent / "categories.csv"
                    if not cats_path.exists():
                        st.error("לא נמצא קובץ categories.csv בתיקיית האפליקציה"); st.stop()
                    all_debits = parse_debit_file(str(bank_path), str(cats_path))
                    debits_matched   = [d for d in all_debits if d["match_method"] == "keyword"]
                    debits_unmatched = [d for d in all_debits if d["match_method"] == "unmatched"]
                except Exception as e:
                    st.warning(f"אזהרה: לא ניתן לנתח הוצאות: {e}")
                    debits_matched, debits_unmatched = [], []

            with st.spinner("טוען רשימת דיירים…"):
                try:
                    tenants = load_tenants(str(roster_path))
                except Exception as e:
                    st.error(f"שגיאה ברשימת דיירים: {e}"); st.stop()

            with st.spinner("מתאים תנועות…"):
                matched, unmatched = match_transactions(
                    transactions, tenants, fuzzy_threshold=threshold
                )

            with st.spinner("כותב לגיליון…"):
                written, skipped = apply_matches(
                    matched, str(ledger_path), month_input, overwrite=overwrite
                )
                try:
                    expense_written, expense_skipped = apply_expense_matches(
                        debits_matched, str(ledger_path), month_input, overwrite=overwrite
                    )
                except Exception as e:
                    st.warning(f"אזהרה: שגיאה בכתיבת הוצאות: {e}")
                    expense_written, expense_skipped = [], []

            st.session_state.matched          = matched
            st.session_state.unmatched        = unmatched
            st.session_state.tenants          = tenants
            st.session_state.ledger_path      = str(ledger_path)
            st.session_state.payment_month    = month_input
            st.session_state.written          = written
            st.session_state.skipped          = skipped
            st.session_state.debits_matched   = debits_matched
            st.session_state.debits_unmatched = debits_unmatched
            st.session_state.expense_written  = expense_written
            st.session_state.expense_skipped  = expense_skipped

            # Summary metrics
            c1, c2, c3, c4, c5, c6 = st.columns(6)
            c1.metric("תנועות סה״כ",      len(transactions))
            c2.metric("התאמות אוטומטיות", len(matched))
            c3.metric("לבדיקה ידנית",     len(unmatched))
            c4.metric("נכתבו לגיליון",    len(written))
            c5.metric("הוצאות שהותאמו",   len(debits_matched))
            c6.metric("הוצאות לבדיקה",    len(debits_unmatched))

            with open(str(ledger_path), "rb") as f:
                st.download_button(
                    "⬇️ הורד גיליון מעודכן",
                    f.read(),
                    file_name=f"האגמית7_כספים_מעודכן_{month_input.replace('/','_')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 – Auto-matches
# ══════════════════════════════════════════════════════════════════════════════
with tab2:
    st.subheader("התאמות אוטומטיות")

    if st.session_state.matched is None:
        st.info("הרץ תהליך התאמה כדי לראות תוצאות")
    else:
        matched = st.session_state.matched
        rows = []
        for r in matched:
            tx = r["transaction"]
            t  = r.get("tenant") or {}
            rows.append({
                "תאריך":        tx["date"],
                "סכום (₪)":     tx["amount"],
                "שם שולח":      tx.get("sender_name") or "—",
                "דירה (רמז)":   tx.get("apt_hint") or "—",
                "דייר שהותאם":  t.get("tenant_name","—"),
                "דירה":         t.get("apartment","—"),
                "שיטה":         r["match_method"],
                "ביטחון":       f"{r['confidence']:.0%}",
                "נכתב":         r.get("write_message",""),
            })
        df = pd.DataFrame(rows)

        # Colour by method (Dark Mode Friendly)
        def row_colour(row):
            if row["שיטה"] == "apt_hint":
                return ["background-color:#1e4620"]*len(row) # Deep Green
            elif row["שיטה"] == "fuzzy_name":
                return ["background-color:#5c4d04"]*len(row) # Deep Yellow/Olive
            return [""]*len(row)

        st.dataframe(
            df.style.apply(row_colour, axis=1),
            use_container_width=True, height=520
        )

        c1, c2, c3 = st.columns(3)
        c1.metric("התאמת דירה (ירוק)",  sum(1 for r in matched if r["match_method"]=="apt_hint"))
        c2.metric("התאמה פאזית (צהוב)", sum(1 for r in matched if r["match_method"]=="fuzzy_name"))
        c3.metric("סה״כ גביה (₪)",       f"{sum(r['transaction']['amount'] for r in matched):,.2f}")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 – Manual review
# ══════════════════════════════════════════════════════════════════════════════
with tab3:
    st.subheader("תנועות לבדיקה ידנית")

    if st.session_state.unmatched is None:
        st.info("הרץ תהליך התאמה כדי לראות תוצאות")
    elif not st.session_state.unmatched:
        st.success("🎉 כל התנועות הותאמו אוטומטית!")
    else:
        unmatched = st.session_state.unmatched
        tenants   = st.session_state.tenants or []
        tenant_options = {
            f"דירה {t['apartment']:>3} – {t['tenant_name']}": t for t in tenants
        }
        st.caption(f"{len(unmatched)} תנועות ממתינות לשיוך")

        for idx, r in enumerate(unmatched):
            tx = r["transaction"]
            label = tx.get("sender_name") or tx["description"]
            with st.expander(f"📌 {tx['date']}  |  ₪{tx['amount']:.2f}  |  {label}", expanded=True):
                col_l, col_r = st.columns([2,1])
                with col_l:
                    st.write("**פרטי בנק:**", tx.get("raw_detail") or "—")
                    st.write("**רמז דירה:**", tx.get("apt_hint") or "לא זוהה")
                    if r.get("tenant"):
                        best = r["tenant"]
                        st.write(f"**הצעת מערכת:** דירה {best['apartment']} – {best['tenant_name']}  ({r['match_detail']})")
                with col_r:
                    chosen = st.selectbox(
                        "שייך לדייר",
                        ["— לא לשייך —"] + list(tenant_options.keys()),
                        key=f"sel_{idx}"
                    )
                    amt = st.number_input("סכום (₪)", value=float(tx["amount"]), key=f"amt_{idx}")
                    if st.button("✏️ כתוב לגיליון", key=f"write_{idx}"):
                        if chosen == "— לא לשייך —":
                            st.warning("נא לבחור דייר")
                        elif not st.session_state.ledger_path:
                            st.error("אין גיליון פתוח")
                        else:
                            tenant = tenant_options[chosen]
                            u = LedgerUpdater(st.session_state.ledger_path)
                            ok, msg = u.write_payment(
                                tenant["apartment"],
                                st.session_state.payment_month,
                                amt
                            )
                            u.save()
                            (st.success if ok else st.error)(msg)
                            if ok:
                                with open(st.session_state.ledger_path, "rb") as f:
                                    st.download_button(
                                        "⬇️ הורד גיליון מעודכן",
                                        f.read(),
                                        file_name="האגמית7_כספים_מעודכן.xlsx",
                                        key=f"dl_{idx}"
                                    )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 – Expenses (הוצאות)
# ══════════════════════════════════════════════════════════════════════════════
with tab4:
    st.subheader("הוצאות – ניתוח חיובים")

    if st.session_state.debits_matched is None:
        st.info("הרץ תהליך התאמה כדי לראות הוצאות")
    else:
        debits_matched   = st.session_state.debits_matched   or []
        debits_unmatched = st.session_state.debits_unmatched or []
        overwrite_exp    = st.checkbox("דרוס ערכים קיימים בהוצאות", value=False, key="overwrite_exp")

        # ── Auto-matched section ──────────────────────────────────────────────
        st.markdown("### ✅ הוצאות שהותאמו אוטומטית")
        if not debits_matched:
            st.info("לא נמצאו הוצאות מוכרות בקובץ הבנק")
        else:
            # Group by category and sum
            from collections import defaultdict
            grouped: dict[str, float] = defaultdict(float)
            group_rows: dict[str, list] = defaultdict(list)
            for d in debits_matched:
                grouped[d["category"]] += d["amount"]
                group_rows[d["category"]].append(d)

            rows = []
            for cat, total in grouped.items():
                txs = group_rows[cat]
                rows.append({
                    "קטגוריה":       cat,
                    "סכום כולל (₪)": f"{total:,.2f}",
                    "מס׳ תנועות":    len(txs),
                    "תאריכים":       ", ".join(t["date"] for t in txs),
                    "גורם":          txs[0].get("entity_name","—"),
                })
            st.dataframe(pd.DataFrame(rows), use_container_width=True)

            exp_written = st.session_state.expense_written or []
            exp_skipped = st.session_state.expense_skipped or []
            ca, cb = st.columns(2)
            ca.metric("נכתבו", len(exp_written))
            cb.metric("דולגו (קיים)",  len(exp_skipped))

            if exp_skipped:
                with st.expander("⚠️ הוצאות שדולגו (תא כבר מכיל ערך)"):
                    st.dataframe(pd.DataFrame([{
                        "קטגוריה": e["category"],
                        "סכום":    e["amount"],
                        "סיבה":    e["write_message"],
                    } for e in exp_skipped]), use_container_width=True)

            if st.button("🔄 כתוב הוצאות מותאמות לגיליון", use_container_width=True, key="write_exp_auto"):
                if not st.session_state.ledger_path:
                    st.error("אין גיליון פתוח")
                else:
                    try:
                        ew, es = apply_expense_matches(
                            debits_matched,
                            st.session_state.ledger_path,
                            st.session_state.payment_month,
                            overwrite=overwrite_exp,
                        )
                        st.session_state.expense_written = ew
                        st.session_state.expense_skipped = es
                        st.success(f"נכתבו {len(ew)} | דולגו {len(es)}")
                        with open(st.session_state.ledger_path, "rb") as f:
                            st.download_button(
                                "⬇️ הורד גיליון מעודכן",
                                f.read(),
                                file_name="האגמית7_כספים_מעודכן_הוצאות.xlsx",
                                key="dl_exp_auto"
                            )
                    except Exception as e:
                        st.error(f"שגיאה בכתיבה: {e}")

        st.divider()

        # ── Manual review section ─────────────────────────────────────────────
        st.markdown("### 🔍 הוצאות לשיוך ידני")
        if not debits_unmatched:
            st.success("🎉 כל ההוצאות שויכו אוטומטית!")
        else:
            # Build category options from the live expense sheet if available
            if st.session_state.ledger_path:
                try:
                    eu = ExpenseUpdater(st.session_state.ledger_path)
                    cat_options = eu.available_categories
                except Exception:
                    cat_options = []
            else:
                cat_options = []

            st.caption(f"{len(debits_unmatched)} הוצאות ממתינות לשיוך")
            for idx, d in enumerate(debits_unmatched):
                label = d.get("description") or d["ref"]
                with st.expander(
                    f"📌 {d['date']}  |  ₪{d['amount']:.2f}  |  {label}", expanded=True
                ):
                    col_l, col_r = st.columns([2, 1])
                    with col_l:
                        st.write("**תיאור:**",        d.get("description") or "—")
                        st.write("**תאור מורחב:**",   d.get("raw_detail")  or "—")
                    with col_r:
                        chosen_cat = st.selectbox(
                            "שייך לקטגוריה",
                            ["— לא לשייך —"] + (cat_options or ["(טען גיליון)"]),
                            key=f"exp_sel_{idx}"
                        )
                        amt = st.number_input(
                            "סכום (₪)", value=float(d["amount"]), key=f"exp_amt_{idx}"
                        )
                        btn_col1, btn_col2 = st.columns(2)
                        _write_clicked = btn_col1.button("✏️ כתוב לגיליון", key=f"exp_write_{idx}", use_container_width=True)
                        _add_clicked   = btn_col2.button("➕ הוסף לסכום",   key=f"exp_add_{idx}",   use_container_width=True)

                        def _guard(chosen, ledger):
                            if chosen == "— לא לשייך —":
                                st.warning("נא לבחור קטגוריה"); return False
                            if not ledger:
                                st.error("אין גיליון פתוח"); return False
                            return True

                        if _write_clicked or _add_clicked:
                            if _guard(chosen_cat, st.session_state.ledger_path):
                                eu2 = ExpenseUpdater(st.session_state.ledger_path)
                                if _write_clicked:
                                    ok, msg = eu2.write_expense(
                                        chosen_cat,
                                        st.session_state.payment_month,
                                        amt,
                                        overwrite=overwrite_exp,
                                    )
                                else:
                                    ok, msg = eu2.add_to_expense(
                                        chosen_cat,
                                        st.session_state.payment_month,
                                        amt,
                                    )
                                # If category is כללי, also write comment from raw_detail
                                if ok and chosen_cat == "כללי":
                                    comment_text = extract_comment_text(d.get("raw_detail", ""))
                                    if comment_text:
                                        c_ok, c_msg = eu2.write_comment(
                                            st.session_state.payment_month, comment_text
                                        )
                                        msg += f"\n{'✓' if c_ok else '⚠️'} הערה: {c_msg}"
                                eu2.save()
                                (st.success if ok else st.error)(msg)
                                if ok:
                                    with open(st.session_state.ledger_path, "rb") as f:
                                        st.download_button(
                                            "⬇️ הורד גיליון מעודכן",
                                            f.read(),
                                            file_name="האגמית7_כספים_מעודכן.xlsx",
                                            key=f"dl_exp_{idx}"
                                        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 – Written log
# ══════════════════════════════════════════════════════════════════════════════
with tab5:
    st.subheader("יומן כתיבה")

    if st.session_state.written is None:
        st.info("הרץ תהליך התאמה כדי לראות יומן")
    else:
        written = st.session_state.written
        skipped = st.session_state.skipped
        st.markdown(f"**נכתבו:** {len(written)}  |  **דולגו:** {len(skipped)}")

        if written:
            st.markdown("#### ✅ נכתבו בהצלחה")
            st.dataframe(pd.DataFrame([{
                "תאריך": r["transaction"]["date"],
                "סכום":  r["transaction"]["amount"],
                "דייר":  (r.get("tenant") or {}).get("tenant_name","—"),
                "דירה":  (r.get("tenant") or {}).get("apartment","—"),
                "תא":    r.get("write_message",""),
            } for r in written]), use_container_width=True)

        if skipped:
            st.markdown("#### ⚠️ דולגו")
            st.dataframe(pd.DataFrame([{
                "תאריך": r["transaction"]["date"],
                "סכום":  r["transaction"]["amount"],
                "דייר":  (r.get("tenant") or {}).get("tenant_name","—"),
                "דירה":  (r.get("tenant") or {}).get("apartment","—"),
                "סיבה":  r.get("write_message",""),
            } for r in skipped]), use_container_width=True)

        if st.session_state.ledger_path:
            with open(st.session_state.ledger_path, "rb") as f:
                st.download_button(
                    "⬇️ הורד גיליון מעודכן",
                    f.read(),
                    file_name=f"האגמית7_כספים_מעודכן.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
